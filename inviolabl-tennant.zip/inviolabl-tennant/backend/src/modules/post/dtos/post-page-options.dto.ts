import { PageOptionsDto } from '../../../common/dto/page-options.dto';

export class PostPageOptionsDto extends PageOptionsDto {}
